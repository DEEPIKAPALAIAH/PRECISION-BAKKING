document.addEventListener("DOMContentLoaded", function () { 
    showPage("home-page"); 
    loadIngredients(); 
});

// Ingredient data with images
const ingredients = [
    { name: "All-Purpose Flour", image: "images/all-purpose-flour.png" },
    { name: "Whole Wheat Flour", image: "images/whole-wheat-flour.png" },
    { name: "Cake Flour", image: "images/cake-flour.png" },
    { name: "Bread Flour", image: "images/bread-flour.png" },
    { name: "Rice Flour", image: "images/rice-flour.png" },
    { name: "Granulated Sugar", image: "images/granulated-sugar.png" },
    { name: "Brown Sugar", image: "images/brown-sugar.png" },
    { name: "Powdered Sugar", image: "images/powdered-sugar.png" },
    { name: "Salted Butter", image: "images/salted-butter.png" },
    { name: "Unsalted Butter", image: "images/unsalted-butter.png" },
    { name: "Milk", image: "images/milk.png" },
    { name: "Buttermilk", image: "images/buttermilk.png" },
    { name: "Honey", image: "images/honey.png" },
    { name: "Baking Soda", image: "images/baking-soda.png" },
    { name: "Table Salt", image: "images/table-salt.png" },
    { name: "Sea Salt", image: "images/sea-salt.png" },
    { name: "Yeast", image: "images/yeast.png" },
    { name: "Cornstarch", image: "images/cornstarch.png" },
    { name: "Cream", image: "images/cream.png" },
    { name: "Cream Cheese", image: "images/cream-cheese.png" },
    { name: "Extract", image: "images/extract.png" },
];

// Ingredient substitutes
const substitutes = {
    "Cake Flour": "All-Purpose Flour",
    "Brown Sugar": "Granulated Sugar",
    "Buttermilk": "Milk",
    "Baking Soda": "Baking Powder",
    "Table Salt": "Sea Salt",
};

// Conversion factors (grams per unit)
const conversionFactors = {
    "All-Purpose Flour": { cup: 120, tablespoon: 7.5, teaspoon: 2.5 },
    "Whole Wheat Flour": { cup: 113, tablespoon: 7, teaspoon: 2.3 },
    "Cake Flour": { cup: 110, tablespoon: 6.9, teaspoon: 2.3 },
    "Bread Flour": { cup: 127, tablespoon: 8, teaspoon: 2.7 },
    "Rice Flour": { cup: 158, tablespoon: 9.9, teaspoon: 3.3 },
    "Granulated Sugar": { cup: 200, tablespoon: 12.5, teaspoon: 4.2 },
    "Brown Sugar": { cup: 220, tablespoon: 13.75, teaspoon: 4.6 },
    "Powdered Sugar": { cup: 120, tablespoon: 7.5, teaspoon: 2.5 },
    "Salted Butter": { cup: 227, tablespoon: 14.2, teaspoon: 4.7 },
    "Unsalted Butter": { cup: 227, tablespoon: 14.2, teaspoon: 4.7 },
    "Milk": { cup: 240, tablespoon: 15, teaspoon: 5 },
    "Buttermilk": { cup: 240, tablespoon: 15, teaspoon: 5 },
    "Honey": { cup: 340, tablespoon: 21.25, teaspoon: 7.1 },
    "Baking Soda": { cup: 220, tablespoon: 13.75, teaspoon: 4.6 },
    "Table Salt": { cup: 292, tablespoon: 18.25, teaspoon: 6.1 },
    "Sea Salt": { cup: 273, tablespoon: 17.1, teaspoon: 5.7 },
    "Yeast": { cup: 150, tablespoon: 9.4, teaspoon: 3.1 },
    "Cornstarch": { cup: 128, tablespoon: 8, teaspoon: 2.7 },
    "Cream": { cup: 240, tablespoon: 15, teaspoon: 5 },
    "Cream Cheese": { cup: 227, tablespoon: 14.2, teaspoon: 4.7 },
    "Extract": { cup: 240, tablespoon: 15, teaspoon: 5 },
};

// Global variables
let selectedIngredient = "";
let history = JSON.parse(localStorage.getItem("history")) || [];

// Show a specific page
function showPage(pageId) {
    document.querySelectorAll(".page").forEach(page => page.style.display = "none");
    document.getElementById(pageId).style.display = "block";
}

// Load ingredients into the grid
function loadIngredients() {
    const container = document.getElementById("ingredient-list");
    container.innerHTML = "";
    ingredients.forEach(ingredient => {
        const img = document.createElement("img");
        img.src = ingredient.image;
        img.alt = ingredient.name;
        img.onclick = () => selectIngredient(ingredient.name);
        container.appendChild(img);
    });
}

// Handle ingredient selection
function selectIngredient(name) {
    selectedIngredient = name;
    checkForSubstitutes();
}

// Check for ingredient substitution
function checkForSubstitutes() {
    if (substitutes[selectedIngredient]) {
        document.getElementById("substitutionMessage").textContent = 
            ${selectedIngredient} is unavailable. Use ${substitutes[selectedIngredient]} instead?;
        document.getElementById("substitution-popup").style.display = "block";
    } else {
        showPage("measurement-page");
    }
}

// Accept substitution
function acceptSubstitution() {
    selectedIngredient = substitutes[selectedIngredient];
    document.getElementById("substitution-popup").style.display = "none";
    showPage("measurement-page");
}

// Decline substitution
function declineSubstitution() {
    document.getElementById("substitution-popup").style.display = "none";
    showPage("measurement-page");
}

// Convert to grams
function convertToGrams() {
    const quantity = parseFloat(document.getElementById("quantity").value);
    const unit = document.querySelector("input[name='unit']:checked")?.value;

    if (!quantity || !unit) {
        alert("Please enter a quantity and select a unit.");
        return;
    }

    if (!conversionFactors[selectedIngredient]) {
        alert("Conversion data not available for this ingredient.");
        return;
    }

    const grams = quantity * conversionFactors[selectedIngredient][unit];
    document.getElementById("conversionResult").textContent = 
        ${quantity} ${unit}(s) of ${selectedIngredient} = ${grams.toFixed(2)} grams;

    saveToHistory(${quantity} ${unit}(s) of ${selectedIngredient} → ${grams.toFixed(2)} grams);
    showPage("result-page");
}

// Save history (Last 5 conversions)
function saveToHistory(entry) {
    history.unshift(entry);
    if (history.length > 5) history.pop();
    localStorage.setItem("history", JSON.stringify(history));
}

// Show conversion history
function showHistory() {
    const historyList = document.getElementById("conversionHistory");
    historyList.innerHTML = history.length 
        ? history.map(entry => <li>${entry}</li>).join("") 
        : "<li>No recent conversions</li>";
    document.getElementById("history-popup").style.display = "block";
}

// Close history popup
function closeHistory() {
    document.getElementById("history-popup").style.display = "none";
}

// Toggle theme
function toggleTheme() {
    document.body.classList.toggle("light-theme");
    document.body.classList.toggle("blue-theme");
}

// Toggle menu options
function toggleMenu() {
    const menu = document.getElementById("menu-options");
    menu.style.display = menu.style.display === "block" ? "none" : "block";
}

// Restart the process
function restartProcess() {
    showPage("home-page");
}